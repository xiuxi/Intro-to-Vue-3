const product = 'Socks'
