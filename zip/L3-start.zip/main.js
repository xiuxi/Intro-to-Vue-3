const app = Vue.createApp({
    data() {
        return {
            product: 'Socks'
        }
    }
})
